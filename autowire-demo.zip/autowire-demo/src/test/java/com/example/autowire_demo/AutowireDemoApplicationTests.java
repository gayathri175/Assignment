package com.example.autowire_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutowireDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
